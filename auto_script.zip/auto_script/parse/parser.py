#importing python modules
import sys
import getopt
import openpyxl
import os
from datetime import datetime
from learning import *

#function to work with xlsx, tha is it reads the input file containing testcase and keywords and return the list containing test cases and keywords
def xlsx(filepath):
    from openpyxl import load_workbook
    workbook = load_workbook(filename=filepath)
    sheet=workbook.active
    for row in sheet.iter_rows(min_row=1,max_row=1):
        for cell in row:
            if cell.value == "Test Summary":
                col1=cell.column
                row1=cell.row
                #print(row1)
                #print(col1)
            if cell.value == "Step":
                col2=cell.column
                row2=cell.row
                #print(row2)
                #print(col2)
            if cell.value == "Expected Result":
                col3=cell.column
                row3=cell.row
    rows=sheet.max_row
    #val=[]
    result=[]
    for i in range(row1+1,rows+1):
        
        val=[]
        val1=sheet.cell(row=i,column=col1).value
        val.append(val1)
        #for j in range(row1+1,rows+1):
        val2=sheet.cell(row=i,column=col2).value
        #val2=val2.split("\n")
        val.append(val2)
        val3=sheet.cell(row=i,column=col3).value
        val.append(val3)
        #print(val)
        result.append(val)
    #print(result)
    return result

#auto script generator
#print("this is the name of the script",sys.argv[0])
#print("this is file name", sys.argv[1])
#print("url is", sys.argv[2])
if sys.argv[0] != None:
    wb= openpyxl.Workbook()
    sheet=wb.active
    i=1
    j=1
    c1=sheet.cell(row=i,column=j)
    c2=sheet.cell(row=i,column=j+1)
    c3=sheet.cell(row=i,column=j+2)
    c1.value="TESTCASE NAME"
    c2.value="STEPS"
    c3.value="VERIFICATION"
    i=1
    j=1
    sheet=wb.active
    value=xlsx(sys.argv[1])
    #print(value)
    steps=[]
    verification=[]
    for element in value:
        filename=element[0]
        testname=element[1]
        expectation=element[2]
        #if filename!=None:
            #print(filename)
            #print("\n")
        #if testname!=None:
            #print(testname)
            #print("\n")
        #if expectation!=None:
            #print(expectation)
            #print("\n")

        
        if filename!=None:
            i=i+1
            steps=[]
            verification=[]
            value1=nlp_1(filename)
            str1=" ".join(value1)
            #print(str1)
            c1=sheet.cell(row=i,column=j)
            c1.value=str1
            
            
        if testname!=None:
            value2=nlp_2(testname)
            str2=" ".join(value2)
            steps.append(str2)
        c2=sheet.cell(row=i,column=2)
        final_steps="\n".join(steps)
        c2.value=final_steps
        #print(steps)

        
        if expectation!=None:
            value3=nlp_3(expectation)
            #print(value3)
            str3=" ".join(value3)
            verification.append(str3)
        c3=sheet.cell(row=i,column=3)
        final_verification="\n".join(verification)
        c3.value=final_verification
    wb.save(r"D:\Eaton\doc\parsed_excel_sheet2.xlsx")
