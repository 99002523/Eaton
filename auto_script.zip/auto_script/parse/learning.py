def nlp_1(filename):
    import nltk 
    from nltk.tokenize import sent_tokenize
    sentences = sent_tokenize(filename)
    #print(len(sentences), 'sentences:', sentences)

    for sentence in sentences:
        words = nltk.word_tokenize(sentence)
        #print(words)
        #print()

    words_no_punc = []
    for w in words:
        words_no_punc.append(w.lower())

    #print(words_no_punc)
    #print("\n")

    from nltk.corpus import stopwords
    stopwords = stopwords.words("english")
    #print(stopwords)
    #print("\n")
    
    clean_words = []
    for w in words_no_punc:
        if w not in stopwords:
            clean_words.append(w)

    return clean_words
    

#nlp_1("TC0038-WebUI-Invite/Add a new user-OK-Validation of end to end scenario for Location admin to add user")

def nlp_2(filename):
    import nltk 
    from nltk.tokenize import sent_tokenize
    sentences = sent_tokenize(filename)
    #print(len(sentences), 'sentences:', sentences)

    for sentence in sentences:
        words = nltk.word_tokenize(sentence)
        #print(words)
        #print()

    words_no_punc = []
    for w in words:
        if w.isalnum():
            words_no_punc.append(w.lower())

    #print(words_no_punc)
    #print("\n")

    from nltk.corpus import stopwords
    stopwords = stopwords.words("english")
    #print(stopwords)
    #print("\n")
    
    clean_words = []
    for w in words_no_punc:
        if w not in stopwords:
            clean_words.append(w)

    return clean_words

#nlp_2("Step 0: Prerequisites:Availability of EATON admin user credentials")


def nlp_3(filename):
    import nltk 
    from nltk.tokenize import sent_tokenize
    sentences = sent_tokenize(filename)
    #print(len(sentences), 'sentences:', sentences)

    for sentence in sentences:
        words = nltk.word_tokenize(sentence)
        #print(words)
        #print()

    words_no_punc = []
    for w in words:
        words_no_punc.append(w.lower())
    #print(words_no_punc)

    #print(words_no_punc)
    #print("\n")

    from nltk.corpus import stopwords
    stopwords = stopwords.words("english")
    #print(stopwords)
    #print("\n")
    
    clean_words = []
    for w in words_no_punc:
        if w not in stopwords:
            clean_words.append(w)
    #print(stopwords)
    #print(clean_words)
    return clean_words
