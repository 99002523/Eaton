#importing python modules
import sys
import getopt
import openpyxl
import os
from datetime import datetime
from itertools import permutations
import os.path
from os import path
import re

#function to work with xlsx, tha is it reads the input file containing testcase and keywords and return the list containing test cases and keywords
def xlsx(filepath):
    from openpyxl import load_workbook
    workbook = load_workbook(filename=filepath)
    sheet=workbook.active
    for row in sheet.iter_rows(min_row=1,max_row=1):
        for cell in row:
            if cell.value == "TESTCASE NAME":
                col1=cell.column
                row1=cell.row
                #print(row1)
                #print(col1)
            if cell.value == "STEPS":
                col2=cell.column
                row2=cell.row
                #print(row2)
                #print(col2)
            if cell.value == "VERIFICATION":
                col3=cell.column
                row3=cell.row
    rows=sheet.max_row
    #val=[]
    result=[]
    for i in range(row1+1,rows+1):
        
        val=[]
        val1=sheet.cell(row=i,column=col1).value
        val.append(val1)
        val2=sheet.cell(row=i,column=col2).value
        val2=val2.split("\n")
        val.append(val2)
        val3=sheet.cell(row=i,column=col3).value
        val3=val3.split("\n")
        val.append(val3)
        result.append(val)
    #print(result)
    return result


def action_picker(inp):
    from openpyxl import load_workbook
    workbook = load_workbook(filename=r"D:\Eaton\doc\action_file.xlsx")
    #workbook = load_workbook(filename=r"C:\Users\OTT\Downloads\apr (1)\apr\action_file.xlsx")
    sheet=workbook.active
    for row in sheet.iter_rows(min_row=1,max_row=1):
        for cell in row:
            if cell.value == "ACTION":
                col1=cell.column
                row1=cell.row
                #print(row1)
                #print(col1)
            if cell.value == "KEY":
                col2=cell.column
                row2=cell.row
                #print(row2)
                #print(col2)
    rows=sheet.max_row
    #val=[]
    result=[]
    for i in range(row1+1,rows+1):
        val=sheet.cell(row=i,column=col1).value
        inp=inp.strip()
        val=val.strip()
        #print(type(val))
        #print(type(inp))
        if val == inp:
            val2=sheet.cell(row=i,column=col2).value
            return [inp,val2]
        

def verification_picker(inp):
    from openpyxl import load_workbook
    workbook = load_workbook(filename=r"D:\Eaton\doc\verification.xlsx")
    #workbook = load_workbook(filename=r"C:\Users\OTT\Downloads\apr (1)\apr\action_file.xlsx")
    sheet=workbook.active
    for row in sheet.iter_rows(min_row=1,max_row=1):
        for cell in row:
            if cell.value == "ACTION":
                col1=cell.column
                row1=cell.row
                #print(row1)
                #print(col1)
            if cell.value == "KEY":
                col2=cell.column
                row2=cell.row
                #print(row2)
                #print(col2)
    rows=sheet.max_row
    #val=[]
    result=[]
    for i in range(row1+1,rows+1):
        val=sheet.cell(row=i,column=col1).value
        inp=inp.strip()
        val=val.strip()
        #print(type(val))
        #print(type(inp))
        if val == inp:
            val2=sheet.cell(row=i,column=col2).value
            return [inp,val2]
        
def testcase_mapper(inp):
    from openpyxl import load_workbook
    workbook = load_workbook(filename=r"D:\Eaton\doc\keywords.xlsx")
    #workbook = load_workbook(filename=r"C:\Users\OTT\Downloads\apr (1)\apr\keywords.xlsx")
    sheet=workbook.active
    for row in sheet.iter_rows(min_row=1,max_row=1):
        for cell in row:
            if cell.value == "KEYWORDS":
                col1=cell.column
                row1=cell.row
                #print(row1)
                #print(col1)
    rows=sheet.max_row
    #val=[]
    result=[]
    val2=""
    for i in range(row1+1,rows+1):
        val=sheet.cell(row=i,column=col1).value
        ver=val.find("verify")
        #print(ver)
        if ver == -1:
            inp=inp.strip()
            val=val.strip()
            #print(val.find(inp))
            if val.find(inp) >= 0:
                val2=sheet.cell(row=i,column=col1).value
                #print(val2)
                return val2
    



def testcase_mapper_verification(inp):
    from openpyxl import load_workbook
    workbook = load_workbook(filename=r"D:\Eaton\doc\keywords.xlsx")
    #workbook = load_workbook(filename=r"C:\Users\OTT\Downloads\apr (1)\apr\keywords.xlsx")
    sheet=workbook.active
    for row in sheet.iter_rows(min_row=1,max_row=1):
        for cell in row:
            if cell.value == "KEYWORDS":
                col1=cell.column
                row1=cell.row
                #print(row1)
                #print(col1)
    rows=sheet.max_row
    #val=[]
    result=[]
    val2=""
    for i in range(row1+1,rows+1):
        val=sheet.cell(row=i,column=col1).value
        ver=val.find("verify")
        #print(ver)
        if ver != -1:
            inp=inp.strip()
            val=val.strip()
            if val.find(inp) >= 0:
                val2=sheet.cell(row=i,column=col1).value
                #print(val2)
                return val2

k=1
l=1


from openpyxl import load_workbook

def writing_in_excel_sheet(elements):
    test_case=elements[0]
    step_case=elements[1]
    verify_case=elements[2]
    #print(test_case)
    #print(step_case)
    #print(verify_case)
    if (path.exists(r"D:\Eaton\doc\testcases.xlsx")):
        wb = load_workbook(r"D:\Eaton\doc\testcases.xlsx")
    else:
        wb = openpyxl.Workbook()
    
    sheet=wb.active
    global k
    k+=1
    c1=sheet.cell(row=1,column=l)
    c2=sheet.cell(row=1,column=l+1)
    c1.value="title"
    c2.value="keywords"
    string1=""
    string2=""
    string3=""
    final_string=""
    for count_ele in range(0,len(verify_case)):
        string1=""
        string2=""
        if type(step_case[count_ele]) == list and len(step_case[count_ele])!= 0:
            for ele in step_case[count_ele]:
                if string1 != "":
                    string1=string1+"\n"+ele
                else:
                    string1=ele
            #print(string1)
        else:
            string1=step_case[count_ele]
        if type(verify_case[count_ele]) == list and len(verify_case[count_ele])!=0:
            for ele in verify_case[count_ele]:
                if string2!="":
                    string2=string2+"\n"+ele
                else:
                    string2=ele
            #print(string2)
        else:
            string2=verify_case[count_ele]
        
        string3=string1+"\n"+string2+"\n"
        final_string=final_string+string3
    #print(final_string)
    c1=sheet.cell(row=k,column=l)
    c2=sheet.cell(row=k,column=l+1)
    #print(final_string)
    c1.value=test_case
    c2.value=final_string
    wb.save(r"D:\Eaton\doc\testcases.xlsx")





   
#auto script generator
#print("this is the name of the script",sys.argv[0])
#print("this is file name", sys.argv[1])
#print("url is", sys.argv[2])
if sys.argv[0] != None:
    value=xlsx(sys.argv[1])
    #print(value)
    t_name=[]
    step=[]
    verify=[]
    for element in value:
        #print("\n")
        filename=element[0]
        testname=element[1]
        expectation=element[2]
        #print(filename)
        #print(testname)
        #print(expectation)
        #operation on file name to create testcasename
        result=filename.find("admin")
        t_name.append(filename[result:])
        #done with retrivng testcase title

        #operation on steps to fetch it
        final_testname=[]
        final_expectation=[]
        key=None
        step=[]
        verification=[]

        
        for i in range(1,len(testname)):
            #print(testname[i])
            found=testname[i].find("login")
            
            #print(found)
            if ["login"] not in step:
                step.append(["login"])
            keys=[]
            #operation for steps
            #for j in range(1,20):
            z="step %s " %str(i)
            t_name=testname[i].replace(z,"")    
            #print(t_name)
            if re.search(r'\d', t_name):
                abc=t_name.replace('.', '')
                #print(abc)
                abc = abc.split(str(1))[1]
                #print(abc)
                for i in range(0, 30):
                    b_final_expectation=[]
                    sub_list1=[]
                    if str(i) in abc:
                        abc = abc.split(str(i))
                        #print(abc)
                        if type(abc) == list and len(abc)!= 0:
                            for j in abc:
                                #print(j)
                                abc = j.strip().split(" ")
                                for i in abc:
                                    key=action_picker(i)
                                    #print(key)
                                    if key!=None:
                                            #print(action)
                                            #print(a1)
                                            #print(action)
                                            removed_action=j.replace(key[0],"")
                                            b_final_expectation.append([removed_action,key[1]])
                                            #print(b_final_expectation)
                                            break
                        final_testname.append(b_final_expectation)
            else:
                #print(t_name)
                splitted_testname=t_name.split(" ")
                #print(splitted_testname)
                for ele in splitted_testname:
                    #print(len(ele))
                    #print(ele)
                    removed_testname=""
                    key=action_picker(ele)
                    if key!=None:
                        #print(key)
                        removed_action=t_name.replace(key[0],"")
                        final_testname.append([removed_action,key[1]])
        step.append(final_testname)
        #print(step)
        #print(final_testname)

        final_keyword=step[0]   #final_keyword has login
        #print(final_keyword)
        for ele in step[1]:
            #print(ele)
            #print(key)
            if type(ele[0]) == list:
                sub_list1=[]
                two_lsist=ele
                for abc in  two_lsist:
                    key=abc[1]
                    abc=abc[0].split()
                    for i in abc:
                        keyword = key + ' ' + i
                        keyword = keyword.strip()
                        second=testcase_mapper(keyword)
                        if second != None and second not in sub_list1:
                            #print(second)
                            sub_list1.append(second)
                            break
                        #print(sub_list1)
                final_keyword.append(sub_list1)
            else:
                key=ele[1]
                #print("#")
                keys=ele[0].split()
                for words in keys:
                    string = key+" "+words.strip()
                    #print("%s",string)
                    found=testcase_mapper(string)
                    if found != None and found not in final_keyword:
                        final_keyword.append(found)
                        break
        #print(final_keyword)
            












    
        
        #start of verfifictaion code
                    
        for ele_e in expectation:
            #print(ele_e)
            #print(type(expectation[0]))
            splitted_exception=ele_e.split("\n")
            #print(expectation[0])
            for a1 in splitted_exception:
                if re.search(r'\d', a1):
                    #print(a1)
                    abc=a1.replace('.', '')
                    string = abc.split(str(1))[0]
                    abc = abc.split(str(1))[1]
                    #print(string)
                    #print(abc)
                    #print(abc)
                    for i in range(1, 3):
                        b_final_expectation=[]
                        if str(i) in abc:
                            abc = abc.split(str(i))
                            if type(abc) == list and len(abc)!= 0:
                                #print(abc)
                                for j in abc:
                                    j=string+j
                                    #print(j)
                                    abc = j.strip().split(" ")
                                    #print(abc)
                                    elements_e = abc
                                    for each_ele_e in elements_e:
                                        #print(each_ele_e)
                                        action=verification_picker(each_ele_e)
                                        if action!=None:
                                            #print(action)
                                            #print(a1)
                                            #print(action)
                                            removed_action=j.replace(action[0],"")
                                            b_final_expectation.append([removed_action,action[1]])
                                            #print(b_final_expectation)
                                            break
                            final_expectation.append(b_final_expectation)
                else:
                    elements_e=a1.split(" ")
                    for each_ele_e in elements_e:
                        #print(each_ele)
                        action=verification_picker(each_ele_e)
                        if action!=None:
                            #print(action)
                            #print(a1)
                            #print(action)
                            removed_action=a1.replace(action[0],"")
                            break
                    final_expectation.append([removed_action,action[1]])



        print()
        #print(final_expectation)
        print()                
        operation=[]
        final_expectation_keys=[]
        count=0
        flag=0
        for ele in final_expectation:
            count+=1
            #print(ele)
            if type(ele[0]) == list:
                sub_list=[]
                suboperation=[]
                two_lists=ele
                #print(two_lists)
                for ele in two_lists:
                    action=ele[1]
                    if action=="verify":
                        abc=ele[0].split()
                        for i in abc:
                            keyword = action + ' ' + i
                            #print(keyword)  
                            second1=testcase_mapper_verification(keyword)
                            if second1 != None and second1 not in sub_list:
                            #print(second)
                                sub_list.append(second1)
                                break
                    else:
                        flag=count
                        abc=ele[0].split()
                        for i in abc:
                            keyword = action + ' ' + i
                            #print(keyword)  
                            second1=testcase_mapper(keyword)
                            if second1 != None and second1 not in suboperation:
                                #print(second1)
                                suboperation.append(second1)
                                break
                if suboperation!=[]:
                    operation.append(suboperation)
                final_expectation_keys.append(sub_list)    
            else:
                action=ele[1]
                actions=ele[0].split()
                for word in actions:
                    string = action+" "+word
                    second1=testcase_mapper_verification(string)
                    if second1 != None: #and second1 not in final_expectation_keys:
                        #print(second1)
                        final_expectation_keys.append(second1)
                        break


        print()     
        #print(filename)
        print(final_keyword)
        print()
        #print(flag)
        print(final_expectation_keys)
        #print(operation)
        #print(final_keyword)
        #print(len(final_expectation_keys))
        writing_in_excel_sheet([filename,final_keyword,final_expectation_keys])
